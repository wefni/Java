import java.lang.Thread;
import static java.lang.Thread.sleep;

public class Application {

    public static void main(String[] args) throws InterruptedException {
        Fifo ff = new Fifo();
        Producer p = new Producer("elso",ff,1000);
        Producer p2 = new Producer("masodik",ff,1000);
        Producer p3 = new Producer("harmadik",ff,1000);
        Consumer c1 = new Consumer(ff,"c1",100);
        Consumer c2 = new Consumer(ff,"c2",100);
        Consumer c3 = new Consumer(ff,"c3",100);
        Consumer c4 = new Consumer(ff,"c4",100);
        Thread t = new Thread(p);
        Thread t2 = new Thread(p2);
        Thread t3 = new Thread(p3);

        t.start();
        t2.start();
        t3.start();
        c1.start();
        c2.start();
        c3.start();
        c4.start();

        try {
            sleep(500);
        }catch (Exception e){}
    }
}
