import java.lang.Thread;

import static java.lang.Thread.sleep;

public class Producer implements Runnable {
    String a;
    Fifo f;
    int var;

    public Producer(String str,Fifo f, int var){
        a = str;
        this.f = f;
        this.var = var;
    }

    public void go() throws InterruptedException {
        int i = 0;
        while(true){
            sleep(var);
            f.put(a+i);
            System.out.println("produced"+ " " + f.get() + " " + System.currentTimeMillis()%100000);
            i++;
        }
    }
    public void run(){
        try {
            this.go();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
