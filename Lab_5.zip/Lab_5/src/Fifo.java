import java.util.LinkedList;

public class Fifo {
    LinkedList<String> lista = new LinkedList<String>();

    public synchronized void put(String str) throws InterruptedException {

        if(lista.size()>9){
            while(lista.size()==10){
                wait();
            }
        }
        lista.add(str);
        notify();
        System.out.println("Put id: " + Thread.currentThread().getId());
    }

    public synchronized String get() throws InterruptedException {
        if(lista.size()>0){
            String s = lista.getFirst();
            lista.remove(0);
            return s;
        }else{
            while(lista.isEmpty()){
                wait();
            }
            notify();
        }
        System.out.println("Get id: " + Thread.currentThread().getId());
        return "";
    }

}
