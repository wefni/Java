import java.util.Comparator;
public class StrengthComparator implements Comparator<Beer>
{
        public int compare(Beer o1, Beer o2)
        {
            return (int) (o1.getstre()- o2.getstre());
        }
}
