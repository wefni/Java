import java.util.Comparator;
public class StyleComparator implements Comparator<Beer>
{
    public int compare(Beer o1, Beer o2)
    {
        return o1.getstyle().compareTo(o2.getstyle());
    }
}
