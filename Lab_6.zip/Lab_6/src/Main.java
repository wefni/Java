import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

public class Main {
    protected static void exit(String[] s) {
        System.exit(0);
    }

    static HashMap<String, Command> commands;

    static {
        commands = new HashMap<>();

        commands.put("list", Beerlist::list);
        commands.put("add", Beerlist::add);
        commands.put("load", Beerlist::load);
        commands.put("save", Beerlist::save);
        commands.put("search", Beerlist::search);
        commands.put("find", Beerlist::find);
        commands.put("delete", Beerlist::delete);
        commands.put("exit", Main::exit);
    }

    public static void main(String[] args) throws IOException//, EmptyQueueException
    {
        Beerlist lista = new Beerlist();

        while (true) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String sor = reader.readLine();
            String[] szavak = sor.split(" ");

            if (commands.containsKey(szavak[0])) {
                commands.get(szavak[0]).execute(szavak);
            }
            else
            {
                System.out.println("Ismeretlen parancs!");
            }
        }
    }
}


