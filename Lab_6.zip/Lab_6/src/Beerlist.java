import java.io.*;
import java.util.*;

public class Beerlist
{

    static ArrayList<Beer> sorok = new ArrayList<Beer>();

    protected static void add(String[] szavak)
    {
        double d = Double.valueOf(szavak[3]);
        Beer b = new Beer(szavak[1], szavak[2], d);
        sorok.add(b);
    }

    static Map<String, Comparator<Beer>> comps = new HashMap<String, Comparator<Beer>>();
    static List<String>lparams;
    static {

        comps.put("name", Comparator.comparing(Beer::getname));
        comps.put("style", Comparator.comparing(Beer::getstyle));
        comps.put("strength", Comparator.comparing(Beer::getstre));

        lparams =new LinkedList<String>();
        lparams.add("name");
        lparams.add("strength");
        lparams.add("style");
    }

    protected static void list(String[] szavak)
    {
        Comparator<Beer> cmp=comps.get("name");
        for( String i :szavak)
        {
            if(lparams.contains(i))
            {
                lparams.remove(i);
                lparams.add(i);
            }
        }
        if(szavak.length!=1)
        {
            for (int j = lparams.size()-1; j>0; j--)
            {
                if(comps.containsKey(lparams.get(j)))
                {
                    cmp = comps.get(lparams.get( j));
                    sorok.sort(cmp);
                }
            }
        }
        for(Beer b:sorok)
        {
            System.out.println(b);
        }

    }

    protected static void load(String[] szavak)
    {
        try
        {
            File file = new File(szavak[1]);
            Scanner myReader = new Scanner(file);
            while (myReader.hasNextLine())
            {
                String data = myReader.nextLine();
                String[] adatok = data.split(" ");
                double d = Double.valueOf(adatok[2]);
                Beer b = new Beer(adatok[0], adatok[1], d);
                sorok.add(b);
            }
            myReader.close();
        } catch (FileNotFoundException e)
        {
            System.out.println("Hiba a fájl olvasásnál!");
            e.printStackTrace();
        }
    }

    protected static void save(String[] szavak) throws IOException
    {
        try {
            File f = new File(szavak[1]);

            if(f.createNewFile())
            {
                FileWriter str = new FileWriter(szavak[1]);
                for (Beer i : sorok)
                {
                    str.write(i.toString() + '\n');
                }
                str.close();
            }
            else
            {
                System.out.println("Már létezik ilyen!");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected static void search(String[] szavak)
    {
        if(szavak.length == 2)
        {
            for(Beer str: sorok)
            {
                if(str.getname().equals(szavak[1]))
                {
                    System.out.println(str.toString());
                }
            }
        }
        else
        {
            if(szavak[1].equals("name"))
            {
                for(Beer str: sorok)
                {
                    if(str.getname().equals(szavak[2]))
                    {
                        System.out.println(str.toString());
                    }
                }
            }
            else if(szavak[1].equals("style"))
            {
                for(Beer str: sorok)
                {
                    if(str.getstyle().equals(szavak[2]))
                    {
                        System.out.println(str.toString());
                    }
                }
            }
            else if(szavak[1].equals("strength"))
            {
                for(Beer str: sorok)
                {
                    double d = Double.valueOf(szavak[2]);
                    if(str.getstre() == d)
                    {
                        System.out.println(str.toString());
                    }
                }
            }
        }

    }

    protected static void find(String[] szavak)
    {
        if(szavak.length == 2)
        {
            for(Beer str: sorok)
            {
                if(str.getname().contains(szavak[1]))
                {
                    System.out.println(str.toString());
                }
            }
        }
        else
        {
            if(szavak[1].equals("name"))
            {
                for(Beer str: sorok)
                {
                    if(str.getname().contains(szavak[2]))
                    {
                        System.out.println(str.toString());
                    }
                }
            }
            else if(szavak[1].equals("style"))
            {
                for(Beer str: sorok)
                {
                    if(str.getstyle().contains(szavak[2]))
                    {
                        System.out.println(str.toString());
                    }
                }
            }
            else if(szavak[1].equals("strength"))
            {
                for(Beer str: sorok)
                {
                    double d = Double.valueOf(szavak[2]);
                    if(str.getstre() >= d)
                    {
                        System.out.println(str.toString());
                    }
                }
            }
            else if(szavak[1].equals("weaker"))
            {
                for(Beer str: sorok)
                {
                    double d = Double.valueOf(szavak[2]);
                    if(str.getstre() <= d)
                    {
                        System.out.println(str.toString());
                    }
                }
            }
        }
    }

    protected static void delete(String[] szavak)
    {
        Iterator<Beer> iter = sorok.iterator();
        while (iter.hasNext())
        {
            Beer a = iter.next();
            if (szavak[1].equals(a.getname()))
            {
                iter.remove();
                System.out.println("Sikeres torles!");
            }
        }
    }
    protected static void exit() {
        System.exit(0);
    }
}

