public class Beer
{
    String name;
    String style;
    double strength;
    Beer(String n, String s, double stre)
    {
        name = n;
        style = s;
        strength = stre;
    }
    public String getname()
    {
        return name;
    }
    public String getstyle()
    {
        return style;
    }
    public double getstre()
    {
        return strength;
    }
    public String toString ()
    {
        return name + " " + style + " " + strength;
    }
}
