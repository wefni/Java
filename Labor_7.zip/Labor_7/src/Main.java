public class Main {

    public static void main(String[] args) {
        CaesarFrame cz = new CaesarFrame();
    }
}