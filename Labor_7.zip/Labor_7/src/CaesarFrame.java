import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CaesarFrame extends JFrame{
    public static JTextField tf;
    public static JTextField tf2;
    public static JButton bt;
    public static JComboBox cb;
    public CaesarFrame(){
        Object let[] = new Object[]{'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
        JFrame f = new JFrame("SwingLab");
        JPanel p = new JPanel();
        JPanel p2 = new JPanel();
        JLabel lab = new JLabel("Output:");


        cb = new JComboBox(let);
        bt = new JButton("Code!");
        tf = new JTextField(20);
        tf2 = new JTextField(20);
        p.setBounds(0,0,400,45);

        p.add(cb);
        p.add(tf);
        p.add(bt);

        p2.setBounds(0,55,400,65);

        p2.add(lab);
        tf2.setEditable(false);
        p2.add(tf2);

        bt.addActionListener(new OkButtonListener());
        f.add(p,BorderLayout.CENTER);
        f.add(p2,BorderLayout.PAGE_END);
        f.setSize(400,110);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private static String caesarCode(String input, char offset){
        input = input.substring(0,1).toUpperCase() + input.substring(1);
        char[] out = input.toCharArray();
        for (int i = 0; i < out.length; i++) {
            out[i] += offset - 'A';
            if (out[i] > 'Z') out[i] -= 'Z' - 'A' + 1;
        }
        return new String(out);
    }

    static class OkButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent arg0){
            char c = (Character) cb.getSelectedItem();
            String txt = caesarCode(tf.getText(),c);
            tf2.setText(txt);
        }
    }


}
